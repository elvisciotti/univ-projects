#include "Contatto.h"
#include "Rubrica.h"
#include "Funzioni.h"
#include "Data.h"
#include <iostream>
#include <ctime>

using namespace std;
const string file_rubrica = "E:/documenti/UNIV/ing_sw/progetto/rubrica.csv";
void stampa_menu( int cls );


int main()
{
  int n_op;
  Rubrica r_principale;
  r_principale.leggidafile( file_rubrica );

  do
  {
    stampa_menu( 1 );
    cin >> n_op;
    switch ( n_op )
    {
      case 7:
        r_principale.aggiungi_contatto();
      break;
      case 6:
        r_principale.stampa_rubrica();
      break;


    }
  }
  while ( n_op != 9 );
  r_principale.scrivisufile( file_rubrica );
  cout << "[ Modifiche correttamente registrate su file ]\n\n";
  pausa();

  return 0;
}

void stampa_menu( int cls )
{
  if ( cls )
    pulisci_schermo();

  Cdata oggi;
  oggi.imposta_corrente();


  cout << "+===========================================\n";
  cout << "|             ---  AGENDA ---               \n";
  cout << "|      " ;   oggi.stampa(1);              cout << "\n" ;
  cout << "|                                                \n";
  cout << "|   1 - Appuntamenti di oggi []                  \n";
  cout << "|   2 - Appuntamenti del ...                      \n";
  cout << "|   3 - Appuntamenti della settimana              \n";
  cout << "|   4 - Appuntamenti dal ... al ...               \n";
  cout << "|   5 - Visualizza prossime scadenze              \n";
  cout << "|                                                 \n";
  cout << "|             ---  RUBRICA ---                    \n";
  cout << "|   6 - Visualizza rubrica                        \n";//
  cout << "|   7 - Inserisci nuovo contatto                  \n";
  cout << "|                                                 \n";
  cout << "|   9 - Salva ed esci                             \n";
  cout << "|  10 - Cancella contatto...                      \n";
  cout << "|  11 - Cancella evento...                        \n";
  cout << "|  12 - Cancella eventi scaduti                   \n";
  cout << "|  13 - Opzioni visualizzazione                   \n";
  cout << "|                                                 \n";
  cout << "+===========================================\n";
  cout << " Operazione da effettuare :";
}



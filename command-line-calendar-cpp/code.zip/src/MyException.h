#ifndef MYEXCEPTION_H
#define MYEXCEPTION_H

#include <exception>
#include <string>
using namespace std;


class MyException : public exception {
  string tipoErr;

public:
  MyException() { tipoErr = "Errore"; }
  MyException(string s) { tipoErr = s; }
  string getError() { return tipoErr; }
};

#endif

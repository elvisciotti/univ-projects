#ifndef RUBRICA_H
#define RUBRICA_H

#include <vector>
#include "Contatto.h"
using namespace std;

class Rubrica
{
  vector<Contatto> elenco_contatti;
  void ordina_contatti();  // dopo lettura e inserimento
 public:
  Rubrica();
  void leggidafile(string nomefile);
  void scrivisufile(string nomefile); //const ?
  void aggiungi_contatto();
  void rimuovi_contatto(Contatto c); //rimuovo da vettore
  void stampa_rubrica() ;
};


#endif

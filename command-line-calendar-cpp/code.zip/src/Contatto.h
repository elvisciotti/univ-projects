#ifndef CONTATTO_H
  #define CONTATTO_H

  #include <string>
using namespace std; // ?


//elemento della Rubrica
class Contatto
{
  string nome;
  string cognome;
  string mail;
  string indirizzo_casa;
  string telefono_casa;
  string indirizzo_ufficio;
  string telefono_ufficio;
  string telefono_cellulare;
  string note;
public:
  Contatto() {};
  Contatto( string n, string c, string m, string ic, string tc, string iu, string tu, string tcel, string no );
  void acquisisci();
  void stampa_contatto() const;
  bool operator == ( const Contatto & n ) const; //per eliminazione
  bool operator < ( const Contatto & n ) const; //per ordinamento rubrica
  string crea_riga_file() const;
};


#endif


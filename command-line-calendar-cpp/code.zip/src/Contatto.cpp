#include "Contatto.h"
#include "Funzioni.h"
#include <iostream>
//#include <algorithm>
//#include "MyException.h"
#include <string>

using namespace std;

void acquisisci_e_controlla( string campo, string & valore );

// ctor
Contatto::Contatto( string n, string c, string m, string ic, string tc, string iu, string tu, string tcel, string no ) : nome( n ), cognome( c ), mail( m ), indirizzo_casa( ic ), telefono_casa( tc ),
     indirizzo_ufficio( iu ), telefono_ufficio( tu ), telefono_cellulare( tcel ), note( no )
     {
}

void Contatto::acquisisci()
{
  cout << "+===========================================\n";
  cout << "|       ---  INSERIMENTO CONTATTO ---       \n";
  cout << "|     \"nd\" per non specificare nulla\n";
  cout << "|\n";
  acquisisci_e_controlla( "| Nome", nome );
  acquisisci_e_controlla( "| Cognome", cognome );
  acquisisci_e_controlla( "| E-mail", mail );
  acquisisci_e_controlla( "| Indirizzo (casa)", indirizzo_casa );
  acquisisci_e_controlla( "| Telefono (casa)", telefono_casa );
  acquisisci_e_controlla( "| Indirizzo (ufficio)", indirizzo_ufficio );
  acquisisci_e_controlla( "| Telefono (ufficio)", telefono_ufficio );
  acquisisci_e_controlla( "| Telefono cellulare", telefono_cellulare );
  acquisisci_e_controlla( "| Note aggiuntive", note );
  cout << "|     [ CONTATTO CORRETTAMENTE INSERITO ]\n";
  cout << "|\n";
  cout << "+===========================================\n";
  pausa();
}


//usato in iterazione nella rubrica
void Contatto::stampa_contatto() const
{
  cout << "+- - - - - - - - - - - - - - - - - - -\n";
  cout << "| " << nome << " " << cognome << " < " << mail << " >" << endl;
  cout << "|  Casa: " << indirizzo_casa << " - Tel. " << telefono_casa << ".\n";
  cout << "|  Ufficio: " << indirizzo_casa << " - Tel. " << telefono_casa << ".\n";
  cout << "|  Cellulare: " << telefono_cellulare << "\n";
}


string Contatto::crea_riga_file() const
{
  string temp = nome + ";" + cognome + ";" + mail + ";" + indirizzo_casa + ";" + telefono_casa + ";" + indirizzo_ufficio + ";"
       + telefono_ufficio + ";" + telefono_cellulare + ";" + note;
  return temp;
}


// chiede l'input e lo memorizza nel valore escudendo punto e virgola
void acquisisci_e_controlla( string campo, string & valore )
{
  string temp;
  bool corretto = false;
  while ( !corretto )
  {
    cout << campo << ": ";
    cin >> temp;
    if ( temp == "nd" || temp == "ND" ) temp = "";
    if ( temp.find( ';' ) == -1 ) corretto = true;
    else
    {
      corretto = false;
      cout << "Il carattere ';' non � ammesso\n";
    }
  }
  valore = temp;
}


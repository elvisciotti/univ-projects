#ifndef DATA_H
  #define DATA_H

  #include <iostream>
  #include <ctime>
  #include <string>
using namespace std;

const string mesi[]={"Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"};
const int duratamesi[]={31,29,31,30,31,30,31,31,30,31,30,31};
const string giorni[]={"Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"};

class Cdata
{
  int giorno;
  int giornosett;
  int mese;
  int anno;
  int ora;
  int minuti;

public:
  Cdata() : giorno( -1 ), mese( -1 ), anno( -1 )
  {
  }

  Cdata( int g, int m, int a ) : giorno( g ), mese( m ), anno( a )
  {
  }

  void imposta_corrente();

  void imposta_orario( int h, int m )
  {
    ora = h;
    minuti = m;
  }

  void stampa(int comprendi_ora) const
  {
    if ( giornosett ) cout << giorni[giornosett] << " ";
    cout << giorno << " " << mesi[mese] << " " << anno << "";
    if ( comprendi_ora )
      cout << " - Ore " << ora << ":" << minuti;
  }
};



// imposta orario corrente
void Cdata::imposta_corrente()
{
  time_t tmp;
  struct tm * tm_corrente;

  time( & tmp );
  tm_corrente = localtime( & tmp );

  giorno = tm_corrente->tm_mday;
  giornosett = tm_corrente->tm_wday;
  mese = tm_corrente->tm_mon;
  anno = 1900 + tm_corrente->tm_year;
  ora = tm_corrente->tm_hour;
  minuti = tm_corrente->tm_min;
}

#endif

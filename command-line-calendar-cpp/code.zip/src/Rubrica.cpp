#include "Rubrica.h"
#include "Contatto.h"
#include "Funzioni.h"
#include "MyException.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

Rubrica::Rubrica()
{
  elenco_contatti.reserve( 25 ); //valuta
}


void Rubrica::ordina_contatti()
{
}


void Rubrica::leggidafile( string nomefile )
{

  try
  {
    fstream RubricaFile;
    RubricaFile.open( nomefile.c_str(), ios::in ); // sola lettura
    if ( RubricaFile.fail() )
      throw MyException( "Errore apertura dati Rubrica!" );

    char str[4096]; //dim massima riga
    while ( !RubricaFile.eof() )
    {
      int comma[9]; //array posizioni separatore
      int i, j;

      str[0] = '\0';
      if ( RubricaFile.getline( str, 4096 ) ) //metto in str la linea corrente
      {
        cout << str << endl << endl; //debug linea
        if ( RubricaFile.fail() )
          throw MyException( "Errore in lettura dati!" );
        // str = "Elvis;Ciotti;posta@elvisciotti.it;Via Ca'bicci n.17;0541928735;;;3338352942;nota mia";

        //metto posizioni dei separatori in un altro array
        for ( i = 0, j = 0; str[i] != '\0' && j<10; i++ )
          if ( str[i] == ';' )
            comma[j++] = i;
        comma[j] = i; //salvo anche posizione ultimo carattere

        string riga_contatto( str ); // char -> string
        riga_contatto.append( ";" );
        i = j = 0;

        string n( riga_contatto, 0, comma[0] - 0 );
        string c( riga_contatto, comma[0] + 1, comma[1] - comma[0] - 1 );
        string m( riga_contatto, comma[1] + 1, comma[2] - comma[1] - 1 );
        string ic( riga_contatto, comma[2] + 1, comma[3] - comma[2] - 1 );
        string tc( riga_contatto, comma[3] + 1, comma[4] - comma[3] - 1 );
        string iu( riga_contatto, comma[4] + 1, comma[5] - comma[4] - 1 );
        string tu( riga_contatto, comma[5] + 1, comma[6] - comma[5] - 1 );
        string tcel( riga_contatto, comma[6] + 1, comma[7] - comma[6] - 1 );
        string no( riga_contatto, comma[7] + 1, comma[8] - comma[7] - 2 );

        // aggiunge questo contatto alla rubrica
        Contatto cont_corr( n, c, m, ic, tc, iu, tu, tcel, n );
        //Contatto cont_corr( riga_contatto, "t", "t", "t", "t", "t", "t", "t", "t" );
        elenco_contatti.push_back( cont_corr );
      }
    }
    ordina_contatti();
    RubricaFile.close();
  }
  catch ( MyException e )
  {
    cout << e.getError() << "\n";
    exit( 1 );
  }
}


void Rubrica::scrivisufile( string nomefile )
{

    fstream RubricaFile;
    RubricaFile.open( nomefile.c_str(), ios::out ); // sola lettura
    if ( RubricaFile.fail() )
      throw MyException( "Errore apertura dati Rubrica!" );

    char str[4096]; //dim massima riga

    vector < Contatto >::iterator it;
    for ( it = elenco_contatti.begin(); it != elenco_contatti.end(); it++ )
    RubricaFile << ( * it ).crea_riga_file() << "\n";
    RubricaFile.close();

}


void Rubrica::aggiungi_contatto()
{
  pulisci_schermo();
  Contatto nuovoc;
  nuovoc.acquisisci();
  elenco_contatti.push_back( nuovoc ); //aggiungo nuovo contatto da shell
  ordina_contatti();
}


void Rubrica::rimuovi_contatto( Contatto c )
{
}


void Rubrica::stampa_rubrica()
{
  pulisci_schermo();
  cout << "+===========================================\n";
  cout << "|             ---  RUBRICA ---               \n";
  cout << "|          [" << elenco_contatti.size() << " contatti presenti ]\n";
  cout << "|\n";
  vector < Contatto >::iterator it;
  for ( it = elenco_contatti.begin(); it != elenco_contatti.end(); it++ )
    ( * it ).stampa_contatto();
  cout << "+===========================================\n";
  pausa();
}

